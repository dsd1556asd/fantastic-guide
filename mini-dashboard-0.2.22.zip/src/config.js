const baseUrl =
  process.env.REACT_APP_MEILI_SERVER_ADDRESS ||
  (process.env.NODE_ENV === 'development'
    ? 'http://192.168.2.19:7061'
    : window.location.origin)

export default baseUrl
