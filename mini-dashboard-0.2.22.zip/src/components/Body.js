import React from 'react'
import { InstantSearch } from 'react-instantsearch-dom'
import styled from 'styled-components'
import { useMeilisearchClientContext } from 'context/MeilisearchClientContext'
import Box from 'components/Box'
import Header from 'components/Header/index'
import BodyWrapper from 'components/BodyWrapper'
import EmptyView from 'components/EmptyView'
import OnBoarding from 'components/OnBoarding'
import Results from 'components/Results'
import Typography from 'components/Typography'

const ContentWrapper = styled.div``

const IndexContent = ({ currentIndex }) => {
  if (!currentIndex) return <OnBoarding />
  if (currentIndex?.stats?.numberOfDocuments > 0) return <Results />
  return (
    <EmptyView>
      <Typography
        variant="typo8"
        style={{ textAlign: 'center' }}
        mb={32}
        color="gray.0"
      >
        未找到数据
      </Typography>
    </EmptyView>
  )
}

const Body = ({
  currentIndex,
  indexes,
  getIndexesList,
  setCurrentIndex,
  requireApiKeyToWork,
  isApiKeyBannerVisible,
}) => {
  const { meilisearchJsClient, instantMeilisearchClient } =
    useMeilisearchClientContext()

  return (
    <InstantSearch
      indexName={currentIndex ? currentIndex.uid : ''}
      searchClient={instantMeilisearchClient}
    >
      <ContentWrapper>
        <Header
          indexes={indexes}
          currentIndex={currentIndex}
          setCurrentIndex={setCurrentIndex}
          requireApiKeyToWork={requireApiKeyToWork}
          client={meilisearchJsClient}
          refreshIndexes={getIndexesList}
          isApiKeyBannerVisible={isApiKeyBannerVisible}
        />
        <BodyWrapper>
          <Box
            width={928}
            m="0 auto"
            py={4}
            display="flex"
            flexDirection="column"
          >
            <IndexContent currentIndex={currentIndex} />
            <footer>版权所有 ©2025 上海达路市政建筑工程有限公司</footer>
          </Box>
        </BodyWrapper>
      </ContentWrapper>
    </InstantSearch>
  )
}

export default Body
