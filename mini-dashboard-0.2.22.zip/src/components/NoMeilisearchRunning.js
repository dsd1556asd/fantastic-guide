import React from 'react'
import Typography from 'components/Typography'
import EmptyView from 'components/EmptyView'
import BodyWrapper from 'components/BodyWrapper'
import Box from 'components/Box'

const NoMeilisearchRunning = () => (
  <BodyWrapper>
    <Box width={928} m="0 auto" py={4} display="flex" flexDirection="column">
      <EmptyView>
        <Typography
          variant="typo8"
          style={{ textAlign: 'center' }}
          mb={3}
          color="gray.0"
        >
          服务不可用
        </Typography>
        <Typography
          variant="typo8"
          style={{ textAlign: 'center' }}
          mb={32}
          color="gray.2"
        >
          请联系管理员
        </Typography>
        <Typography
          variant="typo8"
          style={{ textAlign: 'center', fontSize: 15 }}
          mb={56}
        >
          版权所有 ©2025 上海达路市政建筑工程有限公司
        </Typography>
      </EmptyView>
    </Box>
  </BodyWrapper>
)

export default NoMeilisearchRunning
