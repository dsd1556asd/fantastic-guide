import React from 'react'

import Box from 'components/Box'
import Typography from 'components/Typography'

const OnBoarding = () => (
  <Box
    display="flex"
    flexDirection="column"
    alignItems="center"
    justifyContent="center"
    height="100%"
  >
    <Typography variant="typo12" mb={42} color="gray.0">
      欢迎使用
    </Typography>
    <Typography mb={42} color="gray.0">
      上海达路市政建筑工程有限公司
    </Typography>
    <Typography variant="typo13" mt={12} color="main.default">
      施工照片搜索
    </Typography>
    <Typography
      variant="typo8"
      color="gray.0"
      style={{ textAlign: 'center' }}
      mt={68}
    >
      版权所有 @2025 上海达路市政建筑工程有限公司
    </Typography>
  </Box>
)

export default OnBoarding
