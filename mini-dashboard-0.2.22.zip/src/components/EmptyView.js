import React from 'react'
import PropTypes from 'prop-types'

import Box from 'components/Box'

const EmptyView = ({ buttonLink, children, ...props }) => (
  <Box
    display="flex"
    height="100%"
    alignItems="center"
    flexDirection="column"
    justifyContent="center"
    m="auto"
    {...props}
  >
    {children}
  </Box>
)

EmptyView.propTypes = {
  /**
   * External link
   */
  buttonLink: PropTypes.string,
  /**
   * Children to be displayed
   */
  children: PropTypes.node,
}

export default EmptyView
