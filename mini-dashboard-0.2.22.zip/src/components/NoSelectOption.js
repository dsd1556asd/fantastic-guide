import React from 'react'

import Box from 'components/Box'
import Typography from 'components/Typography'

const NoSelectOption = () => (
  <Box
    py={3}
    px={24}
    backgroundColor="white"
    display="flex"
    flexDirection="column"
    justifyContent="center"
    alignItems="center"
  >
    <Typography variant="typo4" color="gray.6" mb={3}>
      no index found
    </Typography>
  </Box>
)

export default NoSelectOption
