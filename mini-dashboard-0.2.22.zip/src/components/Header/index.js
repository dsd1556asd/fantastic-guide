import React from 'react'
import styled from 'styled-components'
import Color from 'color'

import { useMeilisearchClientContext } from 'context/MeilisearchClientContext'
import NoSelectOption from 'components/NoSelectOption'
import SearchBox from 'components/SearchBox'
import Box from 'components/Box'
import Select from 'components/Select'
import { MeilisearchLogo, Indexes } from 'components/icons'
// import MenuBarsIcon from 'components/icons/heroicons/MenuBarsIcon'
// import Button from 'components/Button'

const HeaderWrapper = styled('div')`
  background-color: white;
  position: sticky;
  top: ${(props) => props.top}px;
  width: 100%;
  padding: 2rem;
  box-shadow: 0px 0px 30px ${(p) => Color(p.theme.colors.gray[0]).alpha(0.15)};
`

const HeaderLayout = styled('div')`
  display: flex;
  align-items: center;
  gap: 1rem;
  height: 100%;
  width: 100%;
`

const SearchBoxWrapper = styled('div')`
  flex-grow: 1;
  margin-left: 2rem;
  margin-right: 2rem;
`

// const IconButton = styled.button`
//   background: none;
//   border: none;
//   cursor: pointer;
//   padding: 8px;
//   display: flex;
//   align-items: center;
//   justify-content: center;
//   svg {
//     width: 24px;
//     height: 24px;
//     color: ${(p) => p.theme.colors.gray[0]};
//   }
//   &:hover svg {
//     color: ${(p) => p.theme.colors.main.default};
//   }
// `

const HeaderContent = styled.div`
  margin-left: 0;
  display: flex;
  align-items: center;
`

const LogoBox = () => (
  <Box
    display="flex"
    flexDirection="column"
    alignItems="center"
    flexShrink={0}
    mr={4}
  >
    {/* Trick to make the logo look centered */}
    <MeilisearchLogo
      title="上海达路市政建筑工程有限公司"
      style={{ height: '40px', marginBottom: '8px' }}
    />
  </Box>
)

const Header = ({
  indexes,
  currentIndex,
  setCurrentIndex,
  refreshIndexes,
  isApiKeyBannerVisible,
  // onPanelToggle,
}) => {
  const { meilisearchJsClient } = useMeilisearchClientContext()
  const [version, setVersion] = React.useState()

  React.useEffect(() => {
    const getMeilisearchVersion = async () => {
      try {
        const res = await meilisearchJsClient.getVersion()
        setVersion(res.pkgVersion)
      } catch (err) {
        // eslint-disable-next-line no-console
        console.log(err)
      }
    }
    getMeilisearchVersion()
  }, [meilisearchJsClient])

  const topPosition = isApiKeyBannerVisible ? 55 : 0
  return (
    <HeaderWrapper top={topPosition}>
      <HeaderContent>
        <HeaderLayout>
          <LogoBox version={version} />
          <Select
            options={indexes}
            icon={<Indexes style={{ height: 22 }} />}
            currentOption={currentIndex}
            onChange={setCurrentIndex}
            noOptionComponent={<NoSelectOption />}
            style={{ width: 216 }}
            onClick={refreshIndexes}
          />
          <SearchBoxWrapper>
            <SearchBox
              refreshIndexes={refreshIndexes}
              currentIndex={currentIndex}
            />
          </SearchBoxWrapper>
          {/* <IconButton
            onClick={onPanelToggle}
            type="button"
            aria-label="Open Panel"
          >
            <MenuBarsIcon />
          </IconButton> */}
          {/* <Button
            variant="bordered"
            as="a"
            href="https://docs.meilisearch.com/learn/getting_started/quick_start.html#add-documents"
            target="_blank"
            style={{ textDecoration: 'none' }}
          >
            上传数据
          </Button> */}
        </HeaderLayout>
      </HeaderContent>
    </HeaderWrapper>
  )
}

export default Header
