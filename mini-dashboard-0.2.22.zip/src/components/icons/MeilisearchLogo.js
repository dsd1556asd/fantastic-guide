import * as React from 'react';

import companyLogo from './company-logo.png';

const SvgMeilisearchLogo = ({ title, titleId, ...props }) => (
  <img
    src={companyLogo}
    alt={title || "上海达路市政建筑工程有限公司"}
    aria-labelledby={titleId}
    {...props}
  />
);

export default SvgMeilisearchLogo;