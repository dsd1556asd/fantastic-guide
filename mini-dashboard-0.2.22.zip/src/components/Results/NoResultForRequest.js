import React from 'react'
import EmptyView from 'components/EmptyView'
import Typography from 'components/Typography'

const NoResultForRequest = () => (
  <EmptyView>
    <Typography
      variant="typo8"
      style={{ textAlign: 'center' }}
      mb={16}
      color="gray.0"
    >
      Sorry mate, no results matching your request
    </Typography>
  </EmptyView>
)

export default NoResultForRequest
