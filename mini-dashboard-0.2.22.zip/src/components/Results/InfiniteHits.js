import React, { useState, useEffect, useRef } from 'react'
import styled from 'styled-components'
import { connectInfiniteHits } from 'react-instantsearch-dom'
import Button from 'components/Button'
import ScrollToTop from 'components/ScrollToTop'
import Hit from './Hit'

const HitsList = styled.ul`
  padding: 0
  margin: 0
  > li + li {
    margin-top: 16px
  }
`

// 检测是否为图片URL的函数
const isAnImage = async (elem) => {
  // Test the standard way with regex and image extensions
  if (
    typeof elem === 'string' &&
    elem.match(/^(https|http):\/\/.*(jpe?g|png|gif|webp)(\?.*)?$/gi)
  )
    return true

  if (typeof elem === 'string' && elem.match(/^https?:\/\//)) {
    // Tries to load an image that is a valid URL but doesn't have a correct extension
    return new Promise((resolve) => {
      const img = new Image()
      img.src = elem
      img.onload = () => resolve(true)
      img.onerror = () => resolve(false)
    })
  }
  return false
}

// 查找包含图片的字段名
const findImageKey = async (array) => {
  const promises = array.map(async (elem) => isAnImage(elem[1]))
  const results = await Promise.all(promises)
  const index = results.findIndex((result) => result)
  const imageField = array[index]
  return imageField?.[0]
}

const InfiniteHits = connectInfiniteHits(({ hits, hasMore, refineNext }) => {
  const [imageKey, setImageKey] = useState(false)
  const buttonRef = useRef(null)
  const containerRef = useRef(null)

  // 获取图片键值的逻辑
  useEffect(() => {
    const getImageKey = async () => {
      setImageKey(hits[0] ? await findImageKey(Object.entries(hits[0])) : null)
    }
    getImageKey()
  }, [hits[0]])

  // 自动点击"Load more"按钮的逻辑
  useEffect(() => {
    const handleScroll = () => {
      if (!hasMore || !buttonRef.current) return

      const buttonRect = buttonRef.current.getBoundingClientRect()

      // 当按钮进入视口时自动点击
      if (buttonRect.top <= window.innerHeight && buttonRect.bottom >= 0) {
        buttonRef.current.click()
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [hasMore, refineNext])

  // 初始加载时也检查一次
  useEffect(() => {
    if (hasMore && buttonRef.current) {
      const buttonRect = buttonRef.current.getBoundingClientRect()
      if (buttonRect.top <= window.innerHeight && buttonRect.bottom >= 0) {
        buttonRef.current.click()
      }
    }
  }, [hasMore])

  return (
    <div ref={containerRef}>
      <HitsList>
        {hits.map((hit, index) => (
          <Hit key={`${hit.objectID}-${index}`} hit={hit} imageKey={imageKey} />
        ))}
      </HitsList>

      {hasMore && (
        <Button
          ref={buttonRef}
          size="small"
          variant="bordered"
          onClick={refineNext}
          style={{ margin: '0 auto', marginTop: 32, display: 'block' }}
        >
          加载更多
        </Button>
      )}

      <ScrollToTop />
    </div>
  )
})

export default InfiniteHits
